# Hi there 👋 I'm Arthur, web developer

📍 I'm based in Angers and Le Mans, France

🚀 I'm currently working on [Spotify-autopsuh](https://github.com/abroudoux/spotify-autopush.git)

📚 I'm currently learning Rust, Docker & Python

🌍 Discover my [Portfolio](https://abroudoux-portfolio.vercel.app/)

## Technos & Tools

[![My Skills](https://skillicons.dev/icons?i=js,typescript,scss,react,tailwind,nestjs,git,bash,nodejs,mongodb,rust,python,postman,docker,postgres,vercel&perline=8)](https://skillicons.dev)

## Last album played

<div>
    <p>Heaven Sent (Between Heavens B-Sides) - Ruby Haunt</p>
    <br>
    <img style="width: 250px;" src="https://i.scdn.co/image/ab67616d0000b273ee79eeb800809590f5523220"/>
</div>
